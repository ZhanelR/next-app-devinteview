"use client"
import { createGlobalStyle } from 'styled-components';

const GlobalStyles = createGlobalStyle`
    body {
        background-color: azure;
    }
`;

export default GlobalStyles;