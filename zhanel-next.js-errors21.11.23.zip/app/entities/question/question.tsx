export interface IQuestion{
    id: string
    title: string
    description: string
    slug: string
}

//создаю пример вопроса 
export const mockQuestion:IQuestion = {
    id: "hggeb23ned",
    title: "How are you?",
    description: "today",
    slug: "how-are-you"
}

//созд массив всех вопросов 
export const mockQuestions:IQuestion[] = [
    mockQuestion, mockQuestion, mockQuestion
]