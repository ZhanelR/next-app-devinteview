import React from 'react';
import Link from 'next/link';
import styled from 'styled-components';
import HeaderLink from './HeaderLink';

const LinksContainer = styled.div`
  display: flex;
  gap: 20px;
`;

export default function Header () {
    return (
    <>
        <LinksContainer>
            <HeaderLink/>
        </LinksContainer>
    </>
    );
};