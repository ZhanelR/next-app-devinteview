"use client"

import React from 'react';
import Link from 'next/link';
import styled from 'styled-components';


const StyledLink = styled.a`
  text-decoration: none;
`;

export default function HeaderLink () {
    return (
    <>
        <Link href="/questions">
            <StyledLink>Questions</StyledLink>
        </Link>
        <Link href="/interview">
            <StyledLink>Interview</StyledLink>
        </Link>
        <Link href="/reports">
            <StyledLink>Reports</StyledLink>
        </Link>
    </>
    );
};
