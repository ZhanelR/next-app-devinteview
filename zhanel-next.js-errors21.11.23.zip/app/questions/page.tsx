
export default function Questions() {
  return (
    <main>
      <h1>Questions List</h1>
      
    </main>
  )
}
