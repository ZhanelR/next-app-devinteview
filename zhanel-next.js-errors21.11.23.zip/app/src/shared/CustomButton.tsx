import React from 'react';
import styled from 'styled-components';

interface ButtonProps {
  width?: string;
  height?: string;
  text: string;
  onClick?: () => void;
  bgColor?: string;
  textColor?: string;
  hoverColor?: string;
}

const Button = styled.button<ButtonProps>`
  width: ${(props) => props.width || '150px'};
  height: ${(props) => props.height || '50px'};
  background-color: ${(props) => props.bgColor || '#3498db'};
  color: ${(props) => props.textColor || '#ffffff'};
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: ${(props) => props.hoverColor || '#2980b9'};
  }
`;

const CustomButton: React.FC<ButtonProps> = ({
  width,
  height,
  text,
  onClick,
  bgColor,
  textColor,
  hoverColor,
}) => {
  return (
    <Button
      width={width}
      height={height}
      bgColor={bgColor}
      textColor={textColor}
      hoverColor={hoverColor}
      onClick={onClick}
    >
      {text}
    </Button>
  );
};

export default CustomButton;
