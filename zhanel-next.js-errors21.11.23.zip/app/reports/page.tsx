export default function Questions() {
  return (
    <main>
      <h1>Reports</h1>
      
    </main>
  )
}



