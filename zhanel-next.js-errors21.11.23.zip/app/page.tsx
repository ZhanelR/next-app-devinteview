"use client"
import React from 'react';
import Link from 'next/link';
import Banner from './src/Banner';
import styled from 'styled-components';
import Header from './components/Header';

const MainContainer = styled.main`
  display: flex;
  flex-direction: column;
`;


export default function Home() {
  return (
    <MainContainer>
      <Header />
      <h1>Hello</h1>
      <Banner />
    </MainContainer>
  );
}