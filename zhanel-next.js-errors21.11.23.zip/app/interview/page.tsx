
export default function Interview() {
    return (
      <main>
        <h1>Interview Questions</h1>
        
      </main>
    )
  }
  